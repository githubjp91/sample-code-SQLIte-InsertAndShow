//
//  dataShowViewController.swift
//  SQLiteDemoFinal
//
//  Created by Mac on 9/25/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import SQLite3

class dataShowViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }

  

}

