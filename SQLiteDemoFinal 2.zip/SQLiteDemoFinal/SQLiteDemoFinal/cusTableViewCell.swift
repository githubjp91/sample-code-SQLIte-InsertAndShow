//
//  cusTableViewCell.swift
//  SQLiteDemoFinal
//
//  Created by Mac on 9/25/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class cusTableViewCell: UITableViewCell {

    @IBOutlet weak var lblID: UILabel!
    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
