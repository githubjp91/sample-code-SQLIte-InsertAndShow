//
//  regist.swift
//  SQLiteDemoFinal
//
//  Created by Mac on 9/25/18.
//  Copyright © 2018 agile. All rights reserved.
//

import Foundation

class registration
{
    var id:Int
    var name:String
    var email:String
    var number:Int
    var city:String
    init(id:Int, name:String , email:String , number:Int , city:String )
    {
        self.id = id
        self.name = name
        self.email = email
        self.number = number
        self.city = city
    }
}
